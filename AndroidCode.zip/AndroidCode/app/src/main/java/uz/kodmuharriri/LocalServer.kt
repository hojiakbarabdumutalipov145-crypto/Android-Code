package uz.kodmuharriri

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

/** Papkadagi (tree uri) yoki xotiradagi fayl yo'lini DocumentFile'ga aylantiradi. */
fun resolveDoc(ctx: Context, treeUri: String, rel: String): DocumentFile? {
    var d: DocumentFile? = DocumentFile.fromTreeUri(ctx, Uri.parse(treeUri))
    for (seg in rel.split("/")) {
        if (seg.isEmpty() || seg == ".") continue
        if (seg == "..") return null
        d = d?.findFile(seg)
        if (d == null) return null
    }
    return d
}

/**
 * Faqat 127.0.0.1 da ishlaydigan kichik HTTP server (VS Code'dagi "Live Server" kabi).
 * Loyiha fayllari JS tomondan beriladi, rasm va boshqa fayllar tanlangan papkadan o'qiladi.
 */
class LocalServer(private val ctx: Context) {

    @Volatile
    var files: Map<String, String> = emptyMap()

    @Volatile
    var rootUri: String = ""

    private var socket: ServerSocket? = null

    @Synchronized
    fun start(): Int {
        val existing = socket
        if (existing != null && !existing.isClosed) return existing.localPort
        val addr = InetAddress.getByName("127.0.0.1")
        var s: ServerSocket? = null
        for (p in 8080..8090) {
            if (s == null) {
                try {
                    s = ServerSocket(p, 20, addr)
                } catch (e: Exception) {
                    s = null
                }
            }
        }
        if (s == null) {
            try {
                s = ServerSocket(0, 20, addr)
            } catch (e: Exception) {
                s = null
            }
        }
        val server = s ?: return 0
        socket = server
        Thread {
            while (!server.isClosed) {
                try {
                    val c = server.accept()
                    Thread { handle(c) }.start()
                } catch (e: Exception) {
                    break
                }
            }
        }.start()
        return server.localPort
    }

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 10000
            val input = BufferedReader(InputStreamReader(c.getInputStream(), Charsets.ISO_8859_1))
            val line = input.readLine() ?: return
            while (true) {
                val h = input.readLine() ?: break
                if (h.isEmpty()) break
            }
            val out = c.getOutputStream()
            val parts = line.split(" ")
            val head = parts.isNotEmpty() && parts[0] == "HEAD"
            if (parts.size < 2 || (parts[0] != "GET" && parts[0] != "HEAD")) {
                respond(out, 405, "text/plain", "405".toByteArray(), false)
                return
            }
            var path = parts[1]
            val q = path.indexOfAny(charArrayOf('?', '#'))
            if (q >= 0) path = path.substring(0, q)
            path = Uri.decode(path).trimStart('/')
            if (path.isEmpty() || path.endsWith("/")) path += "index.html"
            if (path.split("/").any { it == ".." }) {
                respond(out, 403, "text/plain", "403".toByteArray(), head)
                return
            }
            val bytes = load(path)
            if (bytes == null) {
                respond(out, 404, "text/plain; charset=utf-8", ("404: " + path).toByteArray(Charsets.UTF_8), head)
            } else {
                respond(out, 200, mime(path), bytes, head)
            }
        } catch (e: Exception) {
            // ulanish uzildi yoki o'qib bo'lmadi
        } finally {
            try {
                c.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun load(path: String): ByteArray? {
        val t = files[path]
        if (t != null) return t.toByteArray(Charsets.UTF_8)
        val root = rootUri
        if (root.isEmpty()) return null
        val f = resolveDoc(ctx, root, path) ?: return null
        if (f.isDirectory) {
            val idx = resolveDoc(ctx, root, "$path/index.html") ?: return null
            return read(idx)
        }
        return read(f)
    }

    private fun read(f: DocumentFile): ByteArray? {
        return try {
            ctx.contentResolver.openInputStream(f.uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
    }

    private fun respond(out: OutputStream, code: Int, type: String, body: ByteArray, head: Boolean) {
        val status = when (code) {
            200 -> "OK"
            403 -> "Forbidden"
            404 -> "Not Found"
            else -> "Method Not Allowed"
        }
        val header = "HTTP/1.1 " + code + " " + status + "\r\n" +
            "Content-Type: " + type + "\r\n" +
            "Content-Length: " + body.size + "\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        out.write(header.toByteArray(Charsets.ISO_8859_1))
        if (!head) out.write(body)
        out.flush()
    }

    companion object {
        fun mime(path: String): String {
            val ext = path.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "html", "htm" -> "text/html; charset=utf-8"
                "css" -> "text/css; charset=utf-8"
                "js", "mjs" -> "application/javascript; charset=utf-8"
                "json" -> "application/json; charset=utf-8"
                "svg" -> "image/svg+xml"
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "gif" -> "image/gif"
                "webp" -> "image/webp"
                "ico" -> "image/x-icon"
                "woff" -> "font/woff"
                "woff2" -> "font/woff2"
                "ttf" -> "font/ttf"
                "mp4" -> "video/mp4"
                "mp3" -> "audio/mpeg"
                "txt", "md" -> "text/plain; charset=utf-8"
                "xml" -> "application/xml; charset=utf-8"
                else -> "application/octet-stream"
            }
        }
    }
}
